//
// Created by Charles Little and Anthony Bazzini on 3/22/19.
//

#include "Song.h"

Song::Song(){

    title = "";
    artist = "";
    size = 0;
}

Song::Song(string t, string a, int s) {

    title = t;
    artist = a;
    size = s;
}

void Song::setTitle(string t){

    title = t;
}

void Song::setArtist(string a){

    artist = a;
}

void Song::setSize(int s){

    size = s;
}

string Song::getTitle() const{
    return title; }

string Song::getArtist() const{
    return artist; }

int Song::getSize() const
{ return size; }

void Song::swap(Song &p){

    //swap implemented here switches the data of two songs
    //rather than switching the songnode within the linked list

    Song temp;

    temp.artist = p.artist;
    temp.title = p.title;
    temp.size = p.size;

    p.artist = this->artist;
    p.title = this->title;
    p.size = this->size;

    this->artist = temp.artist;
    this->title = temp.title;
    this->size = temp.size;

    *this = temp;

}

bool Song::operator ==(Song const &rhs){


    return((this->artist == rhs.artist) &&
    (this->title == rhs.title) &&
    (this->size == rhs.size));

}

bool Song::operator !=(Song const &rhs){

    return((this->artist != rhs.artist) ||
    (this->title != rhs.title) ||
    (this->size != rhs.size));

}

bool Song::operator <(Song const &rhs){

    //priority artist:title:size

    if(this->artist != rhs.artist){
        return(this->artist < rhs.artist);
    }

    if(this->title != rhs.title) {
        return (this->title < rhs.title);
    }

    if(this->size != rhs.size){
        return (this->size < rhs.size);
    }

    else{
        return false;
    }
}

bool Song::operator >(Song const &rhs){

    if(this->artist != rhs.artist){
        return(this->artist > rhs.artist);
    }

    if(this->title != rhs.title) {
        return (this->title > rhs.title);
    }

    if(this->size != rhs.size){
        return (this->size > rhs.size);
    }

    else{
        return false;
    }
}
