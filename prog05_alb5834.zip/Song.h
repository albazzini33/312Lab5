//
// Created by Charles Little and Anthony Bazzini on 3/22/19.
//

#ifndef SONG_H
#define SONG_H

#include <iostream>
#include <cstdlib>

using namespace std;

class Song
{

private:

    string title;
    string artist;
    int size;

public:

    Song();
    Song(string t, string a, int s);
    void setTitle(string n);
    void setArtist(string a);
    void setSize(int s);

    string getTitle() const;

    string getArtist() const;

    int getSize() const;

    void swap(Song &p);

    bool operator ==(Song const &rhs);
    bool operator !=(Song const &rhs);
    bool operator <(Song const &rhs);
    bool operator >(Song const &rhs);
};


#endif //SONG_H
