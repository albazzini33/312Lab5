//
// Created by Charles Little and Anthony Bazzini on 3/22/19.
//

#include "UtPod.h"


using namespace std;

UtPod::UtPod() {

    songs = NULL;
    podMemSize = MAX_MEMORY;

}

UtPod::UtPod(int size) {

    if ((size > MAX_MEMORY) || (size <= 0))
        podMemSize = MAX_MEMORY;

    else{
        podMemSize = size;
    }
}

int UtPod::addSong(Song const &s) {

    //Adds a SongNode to the front of the linked list


    if ((s.getSize()) <= this->getRemainingMemory()){

        SongNode *temp = new SongNode;   //create new node
        temp->s = s;
        temp->next = songs;   //set next to the previous head
        songs = temp;        //make the new head the newly added song

        return SUCCESS;

    }

    else
        return NO_MEMORY;  //return failure to add song


}

int UtPod::removeSong(Song const &s) {

    SongNode *tempCurrent = songs;
    SongNode *tempPrevious = NULL;

    if (tempCurrent == NULL){

        return NOT_FOUND;
    }

    if (tempCurrent->s == s){

        songs = tempCurrent->next;
        delete (tempCurrent);
        return SUCCESS;
    }

    else {

        tempPrevious = tempCurrent;
        tempCurrent = tempPrevious->next;

        while (tempCurrent != NULL) {

            if (tempCurrent->s == s) {

                tempPrevious->next = tempCurrent->next;
                delete (tempCurrent);
                return SUCCESS;

            } else {

                tempPrevious = tempCurrent;
                tempCurrent = tempPrevious->next;

            }
        }
    }
}

int UtPod::getLength(UtPod *pod){

    SongNode *head;
    head = pod->songs;
    int length = 0;

    if (head == NULL) {

        return 0;
    }

    else {

        while (head != NULL) {    //go through the linked list and count the number of nodes
            length = length + 1;
            head = head->next;
        }
        return length;
    }
}

int UtPod::swap(Song s1, Song s2){  //swap properly works, passed given two songs

    //this takes a song node, but should take a song
    //actually, should only take a song if the swap function isn't working at all

    //need two temp nodes
    //set the first temp node to the first node encountered during linked list crawl
    //do this so the entire list isn't looked through multiple times
    //look through the rest of the list until the other one has been found
    //
    //then need to swap what points to them and what they point to
    //s1 previous to s2, s2 next = s1 next
    //s2 previous to s1, s1 next = s2 next
    SongNode *tempFirst = songs;  //don't need to pass in the UtPod name because it will be called t.swap(s1, s2);
    SongNode *tempSecond = NULL;

    bool choice = true;  //true means s1 is selected as first node to search from, false means s2 is selected
    int index = 0;

    int length = getLength(this); //uses helper function to get the total number of nodes in the linked list for indexing

    if (tempFirst == NULL){

        return NOT_FOUND;
    }


    for (int i = 0; i < length - 1; i++){

        //tempFirst = tempFirst->next;

        if ((tempFirst->next == NULL) && ((tempFirst->s != s1) && (tempFirst->s != s2))){
            return NOT_FOUND;
        }

        else if (tempFirst->s == s1){   //can break here because now the first node has the correct address

            choice = true;   //select s1 as the first node
            break;   //break to next loop. first node has been selected
        }

        else if (tempFirst->s == s2){  //can break after updating first node to be the same pointer as node found in second

            choice = false;     //select s2 as the second node
            break;
        }

        index = index + 1;
        tempFirst = tempFirst->next;
    }

    tempSecond = tempFirst;

    //Go through the loop to find s2 after s1 has been found, or through to find s1 if s2 has been found
    for (int j = index; j < length - 1; j++){


        if(choice){


            if ((tempSecond->next == NULL) && ((tempSecond->s != s2))){

                return NOT_FOUND;  //tempSecond will contain a pointer, but how far will this break. Need to break from the for loo
            }

            else if(tempSecond->s == s2){

                break; //tempSecond will contain a pointer to the correct node now.
            }
        }

        if(!choice){ //s2 has initially been selected as tempFirst


            if ((tempSecond->next == NULL) && ((tempSecond->s != s1))){

                return NOT_FOUND;  //tempSecond will contain a pointer, but how far will this break. Need to break from the for loo
            }

            else if(tempSecond->s == s1){

                break; //tempSecond will contain a pointer to the correct node now.
            }
        }
        tempSecond = tempSecond->next;  //tempFirst will contain a pointer to s1
    }

    //Out of the search section here, need to now switch the data of the linked list stuff. This makes the algorithm easier
    //considering that the nodes of the linked list aren't switched, just the data

    tempFirst->s.swap(tempSecond->s);   //this should properly swap the two songs in the list

}

void UtPod::shuffle() {

    //for each entry in linked list generate random number % 2. 0 will be no 1 will be true on swapping
    //then generate random number within the range of the length of the linked list to see which number to swap with
    //swap if swap is there.
    // go through whole list once
    // now randomized

    //need length of linked list helper function
    bool swap = false;    // checking this will determine whether or not a given node is to be swapped
    int length = getLength(this);

    SongNode *tempOne = songs;
    SongNode *tempTwo = songs;

   unsigned int r = 0;

   if(songs == NULL){

       return;    //the list is empty, don't shuffle
   }

    //seed rng here
    srand(time(NULL));   //seed the rng

    for (int i = 0; i < length - 1; i++){

        //need null check here
        //get random number and find out whether or not it's even or odd and update swap bool accordingly
        r = rand() % 2;

        if ((rand() % 2) == 0){   //even numbers swap
            swap = true;
        }

        else if ((rand() % 2) == 1){  //odd numbers do not swap
            swap = false;
        }

        //need to keep track of which node the first one is one and which node the second one will be on to pass teh
        if(swap){

            r = rand() % length;

            for (int j = 0; j < r; j++){ //Go through the list to select the one to be swapped

                tempTwo = tempTwo->next;
            }

            tempOne->s.swap(tempTwo->s);   //use song class swap to switch the data rather than swapping the actual nodes
        }

        tempOne = tempOne->next;  //go to the next one in the list
        tempTwo = songs;     //reset the tempTwo for the next time around

    }
}




void UtPod::showSongList() {

    SongNode *head = songs;

    if (songs != NULL){    //go through the list recursively to show the song list.
        //could implement this iteratively if feeling like there is an issue here
        songs = songs->next;
        showSongList();
        cout << head->s.getTitle() << ", " << head->s.getArtist() << ", " << head->s.getSize() << "MB" <<endl;

    }

    songs = head;  //return the head pointer
}

void UtPod::sortSongList() {

    //can implement bubble sort for ascending order
    SongNode *tempCurrent = songs;

    int length = getLength(this);

    if (songs == NULL) {
        return; //0 node in the linked list, so do nothing
    }

    for (int i = 0; i < length - 1; i++) {

        for (int j = 0; j < length - i - 1 ; j++) {      //after first iteration, very last number is sorted
            //each succesive iteration sorts the next to last number, excluding previous last until all sorted
            if (tempCurrent->next == NULL){
                break;
            }
            if (tempCurrent->s < tempCurrent->next->s) {  //if current has smaller song, switch it with the next.
                (tempCurrent->s).swap(tempCurrent->next->s); //this happens until each number in the ll is sorted
            }
            //go to next song.
            tempCurrent = tempCurrent->next;
        }

        tempCurrent = songs;  //restart at the beginning of the list.
    }

}

void UtPod::clearMemory() {

    SongNode *tempCurrent = songs;
    SongNode *tempNext = NULL;

    while (tempCurrent != NULL) {  //go through the ll and delete each node

        tempNext = tempCurrent->next;
        delete(tempCurrent);
        tempCurrent = tempNext;
    }

    songs = NULL;
}



int UtPod::getTotalMemory() {

    return this->podMemSize;
}


int UtPod::getRemainingMemory() {


    SongNode *head = songs;
    int total = 0;

    while (songs != NULL){   //go through linked list and count up the total amount of memory

        total = total + songs->s.getSize();
        songs = songs->next;
    }

    songs = head;  //reset the head node to the beginning

    return this->getTotalMemory() - total;
}


UtPod::~UtPod() {

    this->clearMemory();
}
